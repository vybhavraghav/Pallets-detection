# Pallets > 2024-11-11 12:48pm
https://universe.roboflow.com/spam-raghav/pallets-e5c5a

Provided by a Roboflow user
License: CC BY 4.0

